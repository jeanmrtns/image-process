#define	MAX_COLOR 255

void brilho(int width, int height, unsigned char matriz[width][height]);