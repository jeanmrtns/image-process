#define MAX_VALUE 255
void sepia(int width, int height, unsigned char buf[width*height][3]);